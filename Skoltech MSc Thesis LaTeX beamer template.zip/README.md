# SkoltechLaTeXtemplates
this repository is created to accumulate all LaTeX templates needed at Skoltech

all code is published on MIT public license (if nothing mention inside the files)
